<?php

namespace App\Models;

<<<<<<< HEAD
use Illuminate\Database\Eloquent\Model;

class Roulette extends Model
{
    //
}
=======

use Illuminate\Database\Eloquent\Model;


class Roulette extends Model
{
protected $table = 'roulette';


protected $fillable = ['option'];
}
>>>>>>> ed8225db0ed5e46e9eadb2935b1cf6ca9e49c762
